using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Can_hide_player : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
