using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;

public class AnimationBehaviour : MonoBehaviour
{
    /*
     * needs:
     * - space for sprites
     * - global rotation down (only set once?)
     */
    SpriteRenderer spriteRenderer;
    private Vector2 groundDirection; // direction "looking" to the ground
    public Vector2 direction;
    public string type; //wether if player- or enemy-sprites should be used
    private int state;
    public float angle;
    //needs to be reworked
    public Sprite up, down, left, right;
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        groundDirection = Vector2.down;
        direction = Vector2.left;
        type = transform.tag;
        angle = 0;
        state = 0;
    }

    void FixedUpdate()
    {
        //do animation here
        getState();
        switch(state)
        {
            case 0:
                spriteRenderer.sprite = right;
                break;
            case 1:
                spriteRenderer.sprite = up;
                break;
            case 2:
                spriteRenderer.sprite = left;
                break;
            case 3:
                spriteRenderer.sprite = down;
                break;
        }
    }

    public void setAngle(float angle)
    {
        if (angle > 360) angle = angle % 360;
        if (angle < 0) angle = 360 + angle;
        this.angle = angle;
    }

    private int getState()
    {
        /*
         * state:
         * 0 = looking right
         * 1 = looking up
         * 2 = looking left
         * 3 = looking down
         */
        //angle += 45;
        state = (int)angle / 90;
        return state;
    }
}
