using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationBehaviour : MonoBehaviour
{
    /*
     * needs:
     * - space for sprites
     * - global rotation down (only set once?)
     */
    private Vector2 groundDirection; // direction "looking" to the ground
    private Vector2 direction;
    void Start()
    {
        groundDirection = Vector2.down;
        direction = Vector2.left;
    }

    void FixedUpdate()
    {
        //do animation here
    }

    public void setDir(Vector2 dir)
    {
        this.direction = dir;
    }
}
