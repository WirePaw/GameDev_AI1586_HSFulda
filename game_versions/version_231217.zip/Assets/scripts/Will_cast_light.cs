using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Will_cast_light : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
