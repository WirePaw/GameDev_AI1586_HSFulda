using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;

public class Can_follow_path : MonoBehaviour
{
    AnimationBehaviour sprite;
    private Vector2 direction;
    public bool isMoving;

    private void Start()
    {
        sprite = this.GetComponentInChildren<AnimationBehaviour>();
        direction = Vector2.right;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //set direction while moving


        if(sprite != null)
        {
            sprite.setDir(direction);
        }
    }

    public Vector2 getDir()
    {
        return direction;
    }
}
