using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Has_sight : MonoBehaviour
{
    public RaycastHit2D hit;
    public LayerMask layerMask;
    private void OnTriggerStay2D(Collider2D collision)
    {

        if (collision.CompareTag("Player"))
        {
            hit = Physics2D.Raycast(transform.position, (collision.transform.position - transform.position).normalized, 20f, layerMask);
            
            if(hit.collider != null)
            {
                Debug.DrawLine(transform.position, hit.transform.position);
            }
        }
    }

    private void OnGUI()
    {
        if (hit.collider != null)
        {
            GUI.Label(new Rect(10, 10, 300, 30), "hit object: "+ hit.collider.tag);
        }
    }
}
